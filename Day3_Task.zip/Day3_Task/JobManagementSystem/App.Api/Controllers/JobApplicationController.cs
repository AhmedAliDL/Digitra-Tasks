﻿using App.Application.Interfaces.Services;
using App.Domain.Enums;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace App.Api.Controllers
{
    [Route("api/")]
    [Authorize]
    [ApiController]
    public class JobApplicationController : ControllerBase
    {
        private readonly IJobApplicationService _jobApplicationService;
        public JobApplicationController(IJobApplicationService jobApplicationService)
        {
            _jobApplicationService = jobApplicationService;
        }
        [Authorize(Roles = "candidate")]
        [HttpGet("applications/my")]
        public async Task<IActionResult> GetMyApplications(CancellationToken cancellationToken)
        {
            var result = await _jobApplicationService.GetMyApplicationsAsync(cancellationToken);
            return Ok(result);
        }
        [HttpGet("applications/{id:guid}")]
        public async Task<IActionResult> GetApplicationById(Guid id, CancellationToken cancellationToken)
        {
            var result = await _jobApplicationService.GetByIdAsync(id, cancellationToken);
            if (result is null)
                return NotFound();
            return Ok(result);
        }
        [Authorize(Roles = "recruiter")]
        [HttpGet("jobs/{jobId:guid}/applications")]
        public async Task<IActionResult> GetApplicationsByJobId(Guid jobId, CancellationToken cancellationToken)
        {
            var result = await _jobApplicationService.GetByJobIdAsync(jobId, cancellationToken);
            return Ok(result);
        }
        [Authorize(Roles = "candidate")]
        [HttpPost("jobs/{id:guid}/apply")]
        public async Task<IActionResult> ApplyToJob(Guid id, [FromQuery] string? cvUrl, CancellationToken cancellationToken)
        {
            var result = await _jobApplicationService.ApplyAsync(id, cvUrl, cancellationToken);
            if (result == Guid.Empty)
                return BadRequest("Failed to apply to the job.");
            return Ok("Successfully applied to the job.");
        }
        [Authorize(Roles = "recruiter")]
        [HttpPut("applications/{id:guid}/status")]
        public async Task<IActionResult> UpdateApplicationStatus(Guid id, [FromBody] ApplicationStatus newStatus, CancellationToken cancellationToken)
        {
            if (!Enum.TryParse(newStatus.ToString(), true, out App.Domain.Enums.ApplicationStatus status))
                return BadRequest("Invalid status value.");
            var result = await _jobApplicationService.UpdateStatusAsync(id, status, cancellationToken);
            if (result == 0)
                return NotFound("Application not found or status not updated.");
            return Ok("Application status updated successfully.");
        }
        [Authorize(Roles = "candidate")]
        [HttpDelete("applications/{id:guid}/cancel")]
        public async Task<IActionResult> CancelApplication(Guid id, CancellationToken cancellationToken)
        {
            await _jobApplicationService.CancelAsync(id, cancellationToken);
            return NoContent();
        }
    }
}
