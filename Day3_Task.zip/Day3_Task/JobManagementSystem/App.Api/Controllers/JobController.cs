﻿using App.Application.DTOs.Jobs;
using App.Application.Interfaces.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace App.Api.Controllers
{
    [Route("api")]
    [Authorize]
    [ApiController]
    public class JobController : ControllerBase
    {
        private readonly IJobService _jobService;
        public JobController(IJobService jobService)
        {
            _jobService = jobService;
        }
        [HttpGet("jobs/{id:guid}")]
        public async Task<IActionResult> GetJobById(Guid id, CancellationToken cancellationToken)
        {
            var result = await _jobService.GetByIdAsync(id, cancellationToken);
            if (result is null)
                return NotFound();
            return Ok(result);
        }
        [Authorize(Roles = "recruiter")]
        [HttpGet("jobs/my")]
        public async Task<IActionResult> GetMyJobs(CancellationToken cancellationToken)
        {
            var result = await _jobService.GetMyJobsAsync(cancellationToken);
            return Ok(result);
        }
        [HttpGet("jobs/active")]
        public async Task<IActionResult> GetActiveJobs(CancellationToken cancellationToken)
        {
            var result = await _jobService.GetActiveJobsAsync(cancellationToken);
            return Ok(result);
        }
        [Authorize(Roles = "recruiter")]
        [HttpPost("jobs")]
        public async Task<IActionResult> CreateJob([FromBody] CreateJobDto request, CancellationToken cancellationToken)
        {
            var result = await _jobService.CreateJobAsync(request, cancellationToken);
            if (result == Guid.Empty)
                return BadRequest(result);
            return Ok(result);
        }
        [Authorize(Roles = "recruiter")]
        [HttpPut("jobs/{id:guid}/close")]
        public async Task<IActionResult> CloseJob(Guid id, CancellationToken cancellationToken)
        {
            await _jobService.CloseJobAsync(id, cancellationToken);
            return NoContent();
        }

        [Authorize(Roles = "recruiter")]
        [HttpDelete("jobs/{id:guid}")]
        public async Task<IActionResult> DeleteJob(Guid id, CancellationToken cancellationToken)
        {
            await _jobService.DeleteJobAsync(id, cancellationToken);
            return NoContent();
        }
    }
}
