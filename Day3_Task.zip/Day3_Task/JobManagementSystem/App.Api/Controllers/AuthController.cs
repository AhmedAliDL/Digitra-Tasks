﻿using App.Application.DTOs.Auth;
using App.Application.Interfaces.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace App.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _authService;

        public AuthController(IAuthService authService)
        {
            _authService = authService;
        }
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginDto request)
        {
            var result = await _authService.Login(request);
            if (result is null)
                return BadRequest(result);
            SetTokenCookie(result.RefreshToken);
            return Ok(result);
        }
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterDto request)
        {
            var result = await _authService.Register(request);
            if (result == Guid.Empty)
                return BadRequest(result);
            return Ok(result);
        }
        [Authorize]
        [HttpPost("refresh-token")]
        public async Task<IActionResult> RefreshToken()
        {
            var token = Request.Cookies["refresh_Token"];
            if (string.IsNullOrEmpty(token))
                return BadRequest("Refresh token is missing.");
            var result = await _authService.RefreshToken(token);
            if (result is null)
                return BadRequest(result);
            return Ok(result);
        }
        private void SetTokenCookie(string token)
        {
            var cookieOptions = new CookieOptions
            {
                HttpOnly = true,
                Expires = DateTime.UtcNow.AddDays(7)
            };
            Response.Cookies.Append("refresh_Token", token, cookieOptions);
        }
        [Authorize]
        [HttpPost("logout")]
        public async Task<IActionResult> Logout()
        {
            var refreshToken = Request.Cookies["refresh_Token"];
            if (string.IsNullOrEmpty(refreshToken))
                return BadRequest("Refresh token is missing.");
            var res = await _authService.Logout(refreshToken);
            if (res.IsSuccess == false)
                return BadRequest(res);
            Response.Cookies.Delete("refresh_Token");
            return NoContent();
        }
    }
}
