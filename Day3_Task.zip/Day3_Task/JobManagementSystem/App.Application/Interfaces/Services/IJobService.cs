using App.Application.DTOs.Jobs;

namespace App.Application.Interfaces.Services;

public interface IJobService
{
    Task<Guid> CreateJobAsync(CreateJobDto dto, CancellationToken cancellationToken = default);

    Task<IReadOnlyList<JobResponseDto>> GetActiveJobsAsync(CancellationToken cancellationToken = default);

    Task<IReadOnlyList<JobResponseDto>> GetMyJobsAsync(CancellationToken cancellationToken = default);

    Task<JobResponseDto> GetByIdAsync(Guid id, CancellationToken cancellationToken = default);
    Task CloseJobAsync(Guid id, CancellationToken cancellationToken = default);

    Task DeleteJobAsync(Guid id, CancellationToken cancellationToken = default);

}
