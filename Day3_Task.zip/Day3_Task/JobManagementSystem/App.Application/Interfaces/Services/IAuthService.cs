using App.Application.DTOs.Auth;
using App.Application.Responses;

namespace App.Application.Interfaces.Services;

public interface IAuthService
{
    Task<Guid> Register(RegisterDto dto);

    Task<TokenRefreshResultDto> Login(LoginDto dto);

    Task<ResponseResult<RefreshTokenDto>> RefreshToken(string token);
    Task<ResponseResult<bool>> Logout(string token);
}
