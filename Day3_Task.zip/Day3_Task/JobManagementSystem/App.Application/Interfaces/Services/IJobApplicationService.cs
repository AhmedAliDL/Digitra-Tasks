using App.Application.DTOs.JobApplications;
using App.Domain.Enums;

namespace App.Application.Interfaces.Services;

public interface IJobApplicationService
{
    Task<Guid> ApplyAsync(Guid jobId, string? cvUrl = null, CancellationToken cancellationToken = default);

    Task<int> UpdateStatusAsync(
        Guid id, ApplicationStatus newStatus, CancellationToken cancellationToken = default);

    Task CancelAsync(Guid id, CancellationToken cancellationToken = default);

    Task<JobApplicationResponseDto> GetByIdAsync(Guid id, CancellationToken cancellationToken = default);

    Task<IReadOnlyList<JobApplicationResponseDto>> GetMyApplicationsAsync(CancellationToken cancellationToken = default);

    Task<IReadOnlyList<JobApplicationResponseDto>> GetByJobIdAsync(Guid jobId, CancellationToken cancellationToken = default);
}
