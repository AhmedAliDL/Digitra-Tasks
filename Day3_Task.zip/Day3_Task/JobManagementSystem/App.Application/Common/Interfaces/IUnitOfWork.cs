using App.Application.Interfaces.Repositories;
using App.Domain.Entities;

namespace App.Application.Common.Interfaces;

public interface IUnitOfWork : IDisposable
{
    IBaseRepository<ApplicationUser> Candidates { get; }
    IBaseRepository<Job> Jobs { get; }
    IBaseRepository<JobApplication> JobApplications { get; }
    Task<int> CompleteAsync(CancellationToken cancellationToken = default);
}
