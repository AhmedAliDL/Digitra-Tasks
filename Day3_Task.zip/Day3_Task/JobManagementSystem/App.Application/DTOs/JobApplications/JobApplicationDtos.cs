using App.Domain.Enums;

namespace App.Application.DTOs.JobApplications;

/// <summary>Payload for applying to a job. CandidateId is resolved from JWT — not provided by client.</summary>

/// <summary>Payload for recruiter status update. RecruiterId is resolved from JWT — not provided by client.</summary>
public record UpdateJobApplicationStatusDto(
    ApplicationStatus NewStatus
);

public record JobApplicationResponseDto(
    Guid Id,
    Guid JobId,
    string JobTitle,
    Guid CandidateId,
    string CandidateName,
    string CVUrl,
    ApplicationStatus Status,
    DateTime AppliedAt,
    DateTime? StatusUpdatedAt,
    DateTime? CancelledAt
);
