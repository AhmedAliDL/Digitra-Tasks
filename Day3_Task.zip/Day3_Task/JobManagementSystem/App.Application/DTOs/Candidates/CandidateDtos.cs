namespace App.Application.DTOs.Candidates;

public record CandidateResponseDto(
    Guid Id,
    Guid UserId,
    string Name,
    string Email,
    string CVUrl
);
