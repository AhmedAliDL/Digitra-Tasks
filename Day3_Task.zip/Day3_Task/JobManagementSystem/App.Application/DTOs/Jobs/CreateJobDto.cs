namespace App.Application.DTOs.Jobs;

public record CreateJobDto(
    string Title,
    string Description
);
