namespace App.Application.DTOs.Jobs;

public record JobResponseDto(
    Guid Id,
    string Title,
    string Description,
    bool IsActive,
    Guid RecruiterId,
    DateTime? ClosedAt,
    int ApplicationCount
);
