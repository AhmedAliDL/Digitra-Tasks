using App.Application.Common.Exceptions;
using App.Application.Common.Interfaces;
using App.Application.DTOs.Auth;
using App.Application.Interfaces.Services;
using App.Application.Responses;
using App.Domain.Entities;
using System.IdentityModel.Tokens.Jwt;

namespace App.Application.Services;

public class AuthService(
    IIdentityService identityService,
    IJwtTokenService jwtTokenService,
    IRoleService roleService) : IAuthService
{

    public async Task<Guid> Register(RegisterDto dto)
    {
        var user = new ApplicationUser
        {
            FName = dto.FName,
            Email = dto.Email,
            LName = dto.LName,
            Address = dto.Address,
            UserName = dto.Email,
            CVUrl = dto.CVUrl
        };

        var result = await identityService.CreateUserAsync(user, dto.Password);
        if (result.Succeeded)
        {
            bool found = await roleService.IsRoleExistsAsync("candidate");
            if (found)
                await roleService.AssignRoleToUserAsync(user, "candidate");
            else
            {
                var res = await roleService.CreateRoleAsync("candidate", "candidate for the system.");
                if (res.Succeeded)
                    await roleService.AssignRoleToUserAsync(user, "candidate");
                else
                {
                    throw new InvalidOperationException("Failed to create user");
                }

            }
        }
        else
        {
            throw new InvalidOperationException($"Failed to create user {result.Errors.FirstOrDefault()?.Description}");
        }
        return user.Id;
    }

    public async Task<TokenRefreshResultDto> Login(LoginDto dto)
    {
        ApplicationUser? user = await identityService.GetUserByEmailAsync(dto.Email) ?? throw new ForbiddenException("Password or Email is invalid.");

        var checkPassword = await identityService.CheckCorrectnessOfPasswordAsync(user, dto.Password);
        if (!checkPassword)
            throw new ForbiddenException("Password or Email is invalid.");
        var token = await jwtTokenService.CreateJWTTokenAsync(user);
        var response = new TokenRefreshResultDto
        {
            AccessToken = new JwtSecurityTokenHandler().WriteToken(token),
            AccessTokenExpiration = token.ValidTo,
            RefreshToken = "",
            RefreshTokenExpiration = token.ValidTo

        };
        if (user.RefreshTokens!.Any(rt => rt.IsActive))
        {
            var activeRefreshToken = user.RefreshTokens!.SingleOrDefault(t => t.IsActive);
            response.RefreshToken = activeRefreshToken!.Token;
            response.RefreshTokenExpiration = activeRefreshToken.ExpiresOn;
        }
        else
        {
            var refreshToken = jwtTokenService.CreateRefreshToken();
            response.RefreshToken = refreshToken.Token;
            response.RefreshTokenExpiration = refreshToken.ExpiresOn;
            user.RefreshTokens!.Add(refreshToken);
        }
        user.IsActive = true;
        user.LastLoginAt = DateTime.UtcNow;
        await identityService.UpdateUserAsync(user);

        return response;
    }

    public async Task<ResponseResult<RefreshTokenDto>> RefreshToken(string token)
    {
        return await jwtTokenService.RefreshTokenAsync(token);
    }
    public async Task<ResponseResult<bool>> Logout(string token)
    {
        return await jwtTokenService.RevokeTokenAsync(token);
    }
}
