using App.Application.Common.Exceptions;
using App.Application.Common.Interfaces;
using App.Application.DTOs.JobApplications;
using App.Application.Interfaces.Services;
using App.Domain.Entities;
using App.Domain.Enums;

namespace App.Application.Services;

public class JobApplicationService(
    ICurrentUserService currentUserService,
    IUnitOfWork unitOfWork) : IJobApplicationService
{
    private Guid RequireCurrentUserId() =>
        currentUserService.UserId ?? throw new UnauthorizedAccessException("User is not authenticated.");

    public async Task<Guid> ApplyAsync(Guid jobId, string? cvUrl = null, CancellationToken cancellationToken = default)
    {
        var userId = RequireCurrentUserId();

        var candidate = await unitOfWork.Candidates.GetByIdAsync(userId, cancellationToken)
                        ?? throw new NotFoundException("Candidate profile not found for the current user.");

        var job = await unitOfWork.Jobs.GetByIdAsync(jobId, cancellationToken)
                  ?? throw new NotFoundException($"Job '{jobId}' was not found.");

        if (!job.IsActive)
            throw new ValidationException("Cannot apply to a closed job listing.");

        var alreadyApplied = await unitOfWork.JobApplications
            .FindAsync(j => j.CandidateId == candidate.Id && j.JobId == jobId, cancellationToken);

        if (alreadyApplied is not null)
            throw new ValidationException("You have already applied for this job.");

        var application = new JobApplication
        {
            Id = Guid.NewGuid(),
            JobId = jobId,
            CandidateId = candidate.Id,
            AppliedAt = DateTime.UtcNow,
            Status = ApplicationStatus.Applied,
            StatusUpdatedAt = DateTime.UtcNow,
            CVUrl = cvUrl ?? candidate.CVUrl
        };


        await unitOfWork.JobApplications.AddAsync(application, cancellationToken);
        await unitOfWork.CompleteAsync(cancellationToken);

        return application.Id;
    }

    public async Task<int> UpdateStatusAsync(
        Guid id, ApplicationStatus newStatus, CancellationToken cancellationToken = default)
    {
        var recruiterId = RequireCurrentUserId();

        var application = await unitOfWork.JobApplications.GetByIdAsync(id, cancellationToken)
                          ?? throw new NotFoundException($"Application '{id}' was not found.");
        var job = await unitOfWork.Jobs.GetByIdAsync(application.JobId, cancellationToken)
                  ?? throw new NotFoundException($"Job '{application.JobId}' was not found.");
        if (job.RecruiterId != recruiterId)
            throw new UnauthorizedAccessException("You do not have permission to update this application.");
        application.Status = newStatus;
        unitOfWork.JobApplications.Update(application);

        return await unitOfWork.CompleteAsync(cancellationToken);
    }


    public async Task CancelAsync(Guid id, CancellationToken cancellationToken = default)
    {
        var userId = RequireCurrentUserId();

        var application = await unitOfWork.JobApplications.GetByIdAsync(id, cancellationToken)
                          ?? throw new NotFoundException($"Application '{id}' was not found.");

        if (application.CandidateId != userId)
            throw new UnauthorizedAccessException("You do not have permission to cancel this application.");

        application.CancelledAt = DateTime.UtcNow;
        application.Status = ApplicationStatus.Cancelled;
        unitOfWork.JobApplications.Update(application);
        await unitOfWork.CompleteAsync(cancellationToken);
    }

    public async Task<JobApplicationResponseDto> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
    {
        var userId = RequireCurrentUserId();

        var application = await unitOfWork.JobApplications.FindAsync(a => a.Id == id, includes: [a => a.Job!], cancellationToken)
                          ?? throw new NotFoundException($"Application '{id}' was not found.");

        if (application.CandidateId != userId && application.Job?.RecruiterId != userId)
            throw new UnauthorizedAccessException("You do not have permission to access this application.");

        return MapToDto(application);
    }

    public async Task<IReadOnlyList<JobApplicationResponseDto>> GetMyApplicationsAsync(CancellationToken cancellationToken = default)
    {
        var userId = RequireCurrentUserId();
        var candidate = await unitOfWork.Candidates.GetByIdAsync(userId, cancellationToken)
                        ?? throw new NotFoundException("Candidate profile not found for the current user.");

        var applications = await unitOfWork.JobApplications.FindAllAsync(a => a.CandidateId == candidate.Id && a.Status != ApplicationStatus.Cancelled, includes: [a => a.Job!], cancellationToken);
        return [.. applications.Select(MapToDto)];
    }

    public async Task<IReadOnlyList<JobApplicationResponseDto>> GetByJobIdAsync(Guid jobId, CancellationToken cancellationToken = default)
    {
        var recruiterId = RequireCurrentUserId();

        var job = await unitOfWork.Jobs.GetByIdAsync(jobId, cancellationToken)
                  ?? throw new NotFoundException($"Job '{jobId}' was not found.");
        Console.WriteLine(recruiterId);
        Console.WriteLine(job.RecruiterId);
        if (job.RecruiterId != recruiterId)
            throw new UnauthorizedAccessException("You do not have permission to access applications for this job.");

        var applications = await unitOfWork.JobApplications.FindAllAsync(a => a.JobId == jobId && a.Status != ApplicationStatus.Cancelled, includes: [a => a.Job!], cancellationToken);
        return [.. applications.Select(MapToDto)];
    }


    private static JobApplicationResponseDto MapToDto(JobApplication a) => new(
        Id: a.Id,
        JobId: a.JobId,
        JobTitle: a.Job?.Title ?? string.Empty,
        CandidateId: a.CandidateId,
        CandidateName: $"{a.Candidate?.FName} {a.Candidate?.LName}" ?? string.Empty,
        CVUrl: a.CVUrl,
        Status: a.Status,
        AppliedAt: a.AppliedAt,
        StatusUpdatedAt: a.StatusUpdatedAt,
        CancelledAt: a.CancelledAt
    );

}
