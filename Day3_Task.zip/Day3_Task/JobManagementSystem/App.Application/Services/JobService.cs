using App.Application.Common.Exceptions;
using App.Application.Common.Interfaces;
using App.Application.DTOs.Jobs;
using App.Application.Interfaces.Services;
using App.Domain.Entities;

namespace App.Application.Services;

public class JobService(
    ICurrentUserService currentUserService,
    IUnitOfWork unitOfWork) : IJobService
{
    private Guid RequireCurrentUserId() =>
        currentUserService.UserId ?? throw new UnauthorizedAccessException("User is not authenticated.");

    public async Task<Guid> CreateJobAsync(CreateJobDto dto, CancellationToken cancellationToken = default)
    {
        var recruiterId = RequireCurrentUserId();

        var job = new Job
        {
            Id = Guid.NewGuid(),
            Title = dto.Title,
            Description = dto.Description,
            IsActive = true,
            RecruiterId = recruiterId,
        };

        await unitOfWork.Jobs.AddAsync(job, cancellationToken);
        await unitOfWork.CompleteAsync(cancellationToken);

        return job.Id;
    }

    public async Task<IReadOnlyList<JobResponseDto>> GetActiveJobsAsync(CancellationToken cancellationToken = default)
    {
        var jobs = await unitOfWork.Jobs.FindAllAsync(j => j.IsActive, includes: [j => j.Applications], cancellationToken);
        return [.. jobs.Select(MapToDto)];
    }

    public async Task<IReadOnlyList<JobResponseDto>> GetMyJobsAsync(CancellationToken cancellationToken = default)
    {
        var recruiterId = RequireCurrentUserId();
        var jobs = await unitOfWork.Jobs.FindAllAsync(j => j.RecruiterId == recruiterId, includes: [j => j.Applications], cancellationToken);
        return [.. jobs.Select(MapToDto)];
    }

    public async Task<JobResponseDto> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
    {
        var job = await unitOfWork.Jobs.GetByIdAsync(id, cancellationToken)
                  ?? throw new NotFoundException($"Job '{id}' was not found.");

        return MapToDto(job);
    }

    public async Task CloseJobAsync(Guid id, CancellationToken cancellationToken = default)
    {
        var recruiterId = RequireCurrentUserId();

        var job = await unitOfWork.Jobs.GetByIdAsync(id, cancellationToken)
                  ?? throw new NotFoundException($"Job '{id}' was not found.");
        if (job.RecruiterId != recruiterId)
            throw new UnauthorizedAccessException("You are not authorized to close this job.");

        if (!job.IsActive)
            throw new ValidationException("This job is already closed.");

        job.IsActive = false;
        job.ClosedAt = DateTime.UtcNow;
        unitOfWork.Jobs.Update(job);
        await unitOfWork.CompleteAsync(cancellationToken);
    }

    public async Task DeleteJobAsync(Guid id, CancellationToken cancellationToken = default)
    {
        var recruiterId = RequireCurrentUserId();

        var job = await unitOfWork.Jobs.GetByIdAsync(id, cancellationToken)
                  ?? throw new NotFoundException($"Job '{id}' was not found.");

        if (job.RecruiterId != recruiterId)
            throw new UnauthorizedAccessException("You are not authorized to delete this job.");

        unitOfWork.Jobs.Delete(job);
        await unitOfWork.CompleteAsync(cancellationToken);
    }

    private static JobResponseDto MapToDto(Job j) => new(
        Id: j.Id,
        Title: j.Title,
        Description: j.Description,
        IsActive: j.IsActive,
        RecruiterId: j.RecruiterId,
        ClosedAt: j.ClosedAt,
        ApplicationCount: j.Applications.Count
    );
}
