﻿using App.Application.Common.Interfaces;

namespace App.Infrastructure.BackgroundJobs
{
    public class AutoCloseExpiredJobsJob(
     IUnitOfWork unitOfWork)
    {
        public async Task ExecuteAsync()
        {
            var cutoffDate = DateTime.UtcNow.AddDays(-30);

            var jobs = await unitOfWork.Jobs
                .FindAllAsync(
                    x => x.IsActive && x.CreatedAt <= cutoffDate,
                    CancellationToken.None);

            foreach (var job in jobs)
            {
                job.IsActive = false;
                job.ClosedAt = DateTime.UtcNow;

                unitOfWork.Jobs.Update(job);
            }

            if (jobs.Any())
            {
                await unitOfWork.CompleteAsync(CancellationToken.None);
            }
        }
    }
}
