﻿using App.Application.DTOs.JobApplications;
using MediatR;

namespace App.Application.JobApplications.Queries.GetApplicationById
{
    public record GetApplicationByIdQuery(Guid ApplicationId) : IRequest<JobApplicationResponseDto>;
}
