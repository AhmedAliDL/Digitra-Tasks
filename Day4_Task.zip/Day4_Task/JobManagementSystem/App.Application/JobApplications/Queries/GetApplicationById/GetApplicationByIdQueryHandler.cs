﻿using App.Application.Common.Exceptions;
using App.Application.Common.Interfaces;
using App.Application.DTOs.JobApplications;
using MediatR;

namespace App.Application.JobApplications.Queries.GetApplicationById
{
    public class GetApplicationByIdQueryHandler(IUnitOfWork unitOfWork, ICurrentUserService currentUserService) : IRequestHandler<GetApplicationByIdQuery, JobApplicationResponseDto>
    {
        public async Task<JobApplicationResponseDto> Handle(GetApplicationByIdQuery request, CancellationToken cancellationToken)
        {
            var userId = currentUserService.UserId ?? throw new UnauthorizedAccessException("User is not authenticated.");

            var application = await unitOfWork.JobApplications.FindAsync(a => a.Id == request.ApplicationId, includes: [a => a.Job!], cancellationToken)
                              ?? throw new NotFoundException($"Application '{request.ApplicationId}' was not found.");

            if (application.CandidateId != userId && application.Job?.RecruiterId != userId)
                throw new UnauthorizedAccessException("You do not have permission to access this application.");

            return new JobApplicationResponseDto(
                Id: application.Id,
                JobId: application.JobId,
                JobTitle: application.Job?.Title ?? string.Empty,
                CandidateId: application.CandidateId,
                CandidateName: $"{application.Candidate?.FName} {application.Candidate?.LName}" ?? string.Empty,
                CVUrl: application.CVUrl,
                Status: application.Status,
                AppliedAt: application.AppliedAt,
                StatusUpdatedAt: application.StatusUpdatedAt,
                CancelledAt: application.CancelledAt
            );
        }
    }
}
