﻿using App.Application.Common.Exceptions;
using App.Application.Common.Interfaces;
using App.Application.DTOs.JobApplications;
using App.Domain.Enums;
using MediatR;

namespace App.Application.JobApplications.Queries.GetMyApplications
{
    public class GetMyApplicationsQueryHandler(IUnitOfWork unitOfWork, ICurrentUserService currentUserService) : IRequestHandler<GetMyApplicationsQuery, IReadOnlyList<JobApplicationResponseDto>>
    {
        public async Task<IReadOnlyList<JobApplicationResponseDto>> Handle(GetMyApplicationsQuery request, CancellationToken cancellationToken)
        {
            var userId = currentUserService.UserId ?? throw new UnauthorizedAccessException("User is not authenticated.");
            var candidate = await unitOfWork.Candidates.GetByIdAsync(userId, cancellationToken)
                            ?? throw new NotFoundException("Candidate profile not found for the current user.");

            var applications = await unitOfWork.JobApplications.FindAllAsync(a => a.CandidateId == candidate.Id && a.Status != ApplicationStatus.Cancelled, includes: [a => a.Job!], cancellationToken);
            return [.. applications.Select(a => new JobApplicationResponseDto(
                Id: a.Id,
                JobId: a.JobId,
                JobTitle: a.Job?.Title ?? string.Empty,
                CandidateId: a.CandidateId,
                CandidateName: $"{a.Candidate?.FName} {a.Candidate?.LName}" ?? string.Empty,
                CVUrl: a.CVUrl,
                Status: a.Status,
                AppliedAt: a.AppliedAt,
                StatusUpdatedAt: a.StatusUpdatedAt,
                CancelledAt: a.CancelledAt
            ))];
        }
    }
}
