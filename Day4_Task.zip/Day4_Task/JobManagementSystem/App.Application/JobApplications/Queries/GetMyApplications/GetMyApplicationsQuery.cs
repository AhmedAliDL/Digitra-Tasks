﻿using App.Application.DTOs.JobApplications;
using MediatR;

namespace App.Application.JobApplications.Queries.GetMyApplications
{
    public record GetMyApplicationsQuery : IRequest<IReadOnlyList<JobApplicationResponseDto>>;
}
