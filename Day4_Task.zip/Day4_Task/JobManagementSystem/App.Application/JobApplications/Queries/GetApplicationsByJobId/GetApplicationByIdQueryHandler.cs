﻿using App.Application.Common.Exceptions;
using App.Application.Common.Interfaces;
using App.Application.DTOs.JobApplications;
using App.Domain.Enums;
using MediatR;

namespace App.Application.JobApplications.Queries.GetApplicationsByJobId
{
    public class GetApplicationByIdQueryHandler(IUnitOfWork unitOfWork, ICurrentUserService currentUserService) : IRequestHandler<GetApplicationsByJobIdQuery, IReadOnlyList<JobApplicationResponseDto>>
    {
        public async Task<IReadOnlyList<JobApplicationResponseDto>> Handle(GetApplicationsByJobIdQuery request, CancellationToken cancellationToken)
        {
            var recruiterId = currentUserService.UserId ?? throw new UnauthorizedAccessException("User is not authenticated.");

            var job = await unitOfWork.Jobs.GetByIdAsync(request.JobId, cancellationToken)
                      ?? throw new NotFoundException($"Job '{request.JobId}' was not found.");
            Console.WriteLine(recruiterId);
            Console.WriteLine(job.RecruiterId);
            if (job.RecruiterId != recruiterId)
                throw new UnauthorizedAccessException("You do not have permission to access applications for this job.");

            var applications = await unitOfWork.JobApplications.FindAllAsync(a => a.JobId == request.JobId && a.Status != ApplicationStatus.Cancelled, includes: [a => a.Job!], cancellationToken);
            return [.. applications.Select(a => new JobApplicationResponseDto(
                Id: a.Id,
                JobId: a.JobId,
                JobTitle: a.Job?.Title ?? string.Empty,
                CandidateId: a.CandidateId,
                CandidateName: $"{a.Candidate?.FName} {a.Candidate?.LName}" ?? string.Empty,
                CVUrl: a.CVUrl,
                Status: a.Status,
                AppliedAt: a.AppliedAt,
                StatusUpdatedAt: a.StatusUpdatedAt,
                CancelledAt: a.CancelledAt
            ))];
        }
    }
}
