﻿using App.Application.DTOs.JobApplications;
using MediatR;

namespace App.Application.JobApplications.Queries.GetApplicationsByJobId
{
    public record GetApplicationsByJobIdQuery(Guid JobId) : IRequest<IReadOnlyList<JobApplicationResponseDto>>;
}
