﻿using App.Application.Common.Exceptions;
using App.Application.Common.Interfaces;
using App.Domain.Entities;
using App.Domain.Enums;
using MediatR;

namespace App.Application.JobApplications.Commands.ApplyForJob
{
    public class ApplyForJobCommandHandler(IUnitOfWork unitOfWork,ICurrentUserService currentUserService) : IRequestHandler<ApplyForJobCommand, Guid>
    {
        public async Task<Guid> Handle(ApplyForJobCommand request, CancellationToken cancellationToken)
        {
            var userId = currentUserService.UserId ?? throw new UnauthorizedAccessException("User is not authenticated.");

            var candidate = await unitOfWork.Candidates.GetByIdAsync(userId, cancellationToken)
                            ?? throw new NotFoundException("Candidate profile not found for the current user.");

            var job = await unitOfWork.Jobs.GetByIdAsync(request.JobId, cancellationToken)
                      ?? throw new NotFoundException($"Job '{request.JobId}' was not found.");

            if (!job.IsActive)
                throw new ValidationException("Cannot apply to a closed job listing.");

            var alreadyApplied = await unitOfWork.JobApplications
                .FindAsync(j => j.CandidateId == candidate.Id && j.JobId == request.JobId, cancellationToken);

            if (alreadyApplied is not null)
                throw new ValidationException("You have already applied for this job.");

            var application = new JobApplication
            {
                Id = Guid.NewGuid(),
                JobId = request.JobId,
                CandidateId = candidate.Id,
                AppliedAt = DateTime.UtcNow,
                Status = ApplicationStatus.Applied,
                StatusUpdatedAt = DateTime.UtcNow,
                CVUrl = request.CvUrl ?? candidate.CVUrl
            };


            await unitOfWork.JobApplications.AddAsync(application, cancellationToken);
            await unitOfWork.CompleteAsync(cancellationToken);

            return application.Id;
        }
    }
}
