﻿using MediatR;

namespace App.Application.JobApplications.Commands.ApplyForJob
{
    public record ApplyForJobCommand(Guid JobId, string? CvUrl = null) : IRequest<Guid>;
}
