﻿using MediatR;

namespace App.Application.JobApplications.Commands.CancelApplication
{
    public record CancelApplicationCommand(Guid JobId) : IRequest<int>;
}
