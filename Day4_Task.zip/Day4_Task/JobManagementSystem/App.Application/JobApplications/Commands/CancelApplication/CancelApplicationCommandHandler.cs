﻿using App.Application.Common.Exceptions;
using App.Application.Common.Interfaces;
using App.Domain.Enums;
using MediatR;

namespace App.Application.JobApplications.Commands.CancelApplication
{
    public class CancelApplicationCommandHandler(IUnitOfWork unitOfWork, ICurrentUserService currentUserService) : IRequestHandler<CancelApplicationCommand, int>
    {
        public async Task<int> Handle(CancelApplicationCommand request, CancellationToken cancellationToken)
        {

            var userId = currentUserService.UserId ?? throw new UnauthorizedAccessException("User is not authenticated.");

            var application = await unitOfWork.JobApplications.GetByIdAsync(request.JobId, cancellationToken) ?? throw new NotFoundException($"Application '{request.JobId}' was not found.");

            if (application.CandidateId != userId)
                throw new UnauthorizedAccessException("You do not have permission to cancel this application.");

            application.CancelledAt = DateTime.UtcNow;
            application.Status = ApplicationStatus.Cancelled;
            unitOfWork.JobApplications.Update(application);
            return await unitOfWork.CompleteAsync(cancellationToken);
        }


    }
}
