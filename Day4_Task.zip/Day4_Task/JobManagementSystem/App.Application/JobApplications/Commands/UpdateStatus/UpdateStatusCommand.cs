﻿using App.Domain.Enums;
using MediatR;

namespace App.Application.JobApplications.Commands.UpdateStatus
{
    public record UpdateStatusCommand(Guid ApplicationId, ApplicationStatus NewStatus) : IRequest<int>;
}
