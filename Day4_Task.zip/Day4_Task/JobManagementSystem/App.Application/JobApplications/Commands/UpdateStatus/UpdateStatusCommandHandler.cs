﻿using App.Application.Common.Exceptions;
using App.Application.Common.Interfaces;
using App.Domain.Enums;
using MediatR;

namespace App.Application.JobApplications.Commands.UpdateStatus
{
    public class UpdateStatusCommandHandler(IUnitOfWork unitOfWork, ICurrentUserService currentUserService) : IRequestHandler<UpdateStatusCommand, int>
    {
        public async Task<int> Handle(UpdateStatusCommand request, CancellationToken cancellationToken)
        {
            var recruiterId = currentUserService.UserId ?? throw new UnauthorizedAccessException("User is not authenticated.");

            var application = await unitOfWork.JobApplications.GetByIdAsync(request.ApplicationId, cancellationToken)
                              ?? throw new NotFoundException($"Application '{request.ApplicationId}' was not found.");
            var job = await unitOfWork.Jobs.GetByIdAsync(application.JobId, cancellationToken)
                      ?? throw new NotFoundException($"Job '{application.JobId}' was not found.");
            if (job.RecruiterId != recruiterId)
                throw new UnauthorizedAccessException("You do not have permission to update this application.");
            if (application.Status == ApplicationStatus.Cancelled)
                throw new ValidationException("Cannot update the status of a cancelled application.");
            if (request.NewStatus == ApplicationStatus.Cancelled)
                throw new ValidationException("Recruiters cannot cancel applications. Candidates can cancel their own applications.");
            if (application.Status == ApplicationStatus.Accepted)
            {
                if (request.NewStatus != ApplicationStatus.Accepted)
                    throw new ValidationException("Cannot change the status of an accepted application.");
                if (request.NewStatus == ApplicationStatus.Interview || request.NewStatus == ApplicationStatus.Rejected || request.NewStatus == ApplicationStatus.Applied)
                    throw new ValidationException("Cannot change the status of an accepted application to Interview, Rejected, or Applied.");
            }
            else if (application.Status == ApplicationStatus.Rejected)
            {
                if (request.NewStatus != ApplicationStatus.Rejected)
                    throw new ValidationException("Cannot change the status of a rejected application.");
                if (request.NewStatus == ApplicationStatus.Interview || request.NewStatus == ApplicationStatus.Accepted || request.NewStatus == ApplicationStatus.Applied)
                    throw new ValidationException("Cannot change the status of a rejected application to Interview, Accepted, or Applied.");
            }
            else if (application.Status == ApplicationStatus.Interview)
            {
                if (request.NewStatus == ApplicationStatus.UnderReview || request.NewStatus == ApplicationStatus.Applied)
                    throw new ValidationException("Cannot change the status of an application from Interview to UnderReview or Applied.");
                if (request.NewStatus != ApplicationStatus.Interview)
                    throw new ValidationException("Cannot change the status of a interview application.");

            }
            else if (application.Status == ApplicationStatus.UnderReview)
            {
                if (request.NewStatus == ApplicationStatus.Applied || request.NewStatus == ApplicationStatus.Accepted ||
                  request.NewStatus == ApplicationStatus.Rejected)
                    throw new ValidationException("Cannot change the status of an application from UnderReview to Applied, Accepted, or Rejected.");
                if (request.NewStatus != ApplicationStatus.UnderReview)
                    throw new ValidationException("Cannot change the status of a underview application.");

            }
            application.Status = request.NewStatus;
            unitOfWork.JobApplications.Update(application);

            return await unitOfWork.CompleteAsync(cancellationToken);
        }
    }
}
