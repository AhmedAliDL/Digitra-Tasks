using App.Domain.Entities;
using Microsoft.AspNetCore.Identity;

namespace App.Application.Common.Interfaces;

public interface IRoleService
{
    Task<List<ApplicationRole>> GetAllRolesAsync();
    Task<IList<string>> GetAllRolesOfUser(ApplicationUser user);
    Task<bool> IsRoleExistsAsync(string roleName);
    Task<IdentityResult> CreateRoleAsync(string roleName, string tion);
    Task<IdentityResult> AssignRoleToUserAsync(ApplicationUser user, string roleName);
    Task<bool> DeleteAssignRoleAsync(ApplicationUser user, string roleName);
    Task<ApplicationRole?> GetRoleAsync(string roleName);
    Task<bool> DeleteRoleAsync(ApplicationRole role);
}
