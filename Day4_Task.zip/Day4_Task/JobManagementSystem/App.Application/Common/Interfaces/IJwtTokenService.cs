using App.Application.DTOs.Auth;
using App.Application.Responses;
using App.Domain.Entities;

using System.IdentityModel.Tokens.Jwt;
namespace App.Application.Common.Interfaces;

public interface IJwtTokenService
{
    Task<JwtSecurityToken> CreateJWTTokenAsync(ApplicationUser user);
    RefreshToken CreateRefreshToken();
    Task<ResponseResult<RefreshTokenDto>> RefreshTokenAsync(string token);
    Task<ResponseResult<bool>> RevokeTokenAsync(string token);
}
