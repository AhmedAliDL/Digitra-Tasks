﻿namespace App.Application
{
    public interface IApplicationMarker
    {
    }
}
