﻿using App.Application.Common.Interfaces;
using App.Application.DTOs.Auth;
using App.Application.Responses;
using MediatR;

namespace App.Application.Auth.Commands.RefreshToken
{
    public class RefreshTokenCommandHandler(IJwtTokenService jwtTokenService) : IRequestHandler<RefreshTokenCommand, ResponseResult<RefreshTokenDto>>
    {
        public async Task<ResponseResult<RefreshTokenDto>> Handle(RefreshTokenCommand request, CancellationToken cancellationToken)
        {
            return await jwtTokenService.RefreshTokenAsync(request.RefreshToken);
        }
    }
}
