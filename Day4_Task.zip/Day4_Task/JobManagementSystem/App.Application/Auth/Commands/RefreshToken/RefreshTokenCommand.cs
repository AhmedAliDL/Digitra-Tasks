﻿using App.Application.DTOs.Auth;
using App.Application.Responses;
using MediatR;

namespace App.Application.Auth.Commands.RefreshToken
{
    public record RefreshTokenCommand(string RefreshToken) : IRequest<ResponseResult<RefreshTokenDto>>;
}
