﻿using App.Application.Common.Interfaces;
using App.Domain.Entities;
using MediatR;

namespace App.Application.Auth.Commands.Register
{
    public class RegisterCommandHandler(
    IIdentityService identityService,
    IRoleService roleService) : IRequestHandler<RegisterCommand, Guid>
    {
        public async Task<Guid> Handle(RegisterCommand request, CancellationToken cancellationToken)
        {
            var user = new ApplicationUser
            {
                FName = request.FName,
                Email = request.Email,
                LName = request.LName,
                Address = request.Address,
                UserName = request.Email,
                CVUrl = request.CVUrl
            };

            var result = await identityService.CreateUserAsync(user, request.Password);
            if (result.Succeeded)
            {
                bool found = await roleService.IsRoleExistsAsync("candidate");
                if (found)
                    await roleService.AssignRoleToUserAsync(user, "candidate");
                else
                {
                    var res = await roleService.CreateRoleAsync("candidate", "candidate for the system.");
                    if (res.Succeeded)
                        await roleService.AssignRoleToUserAsync(user, "candidate");
                    else
                    {
                        throw new InvalidOperationException("Failed to create user");
                    }

                }
            }
            else
            {
                throw new InvalidOperationException($"Failed to create user {result.Errors.FirstOrDefault()?.Description}");
            }
            return user.Id;
        }
    }
}
