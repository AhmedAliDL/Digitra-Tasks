﻿using MediatR;
using System.ComponentModel.DataAnnotations;

namespace App.Application.Auth.Commands.Register
{
    public record RegisterCommand : IRequest<Guid>
    {
        public string FName { get; set; } = null!;
        public string LName { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string? Address { get; set; }
        [DataType(DataType.Password)]
        public string Password { get; set; } = null!;
        [DataType(DataType.Password)]
        [Compare(nameof(Password), ErrorMessage = "Confirmed Password field must match Password field")]
        public string ConfirmPassword { get; set; } = null!;
        public string CVUrl { get; set; } = null!;
    }
}
