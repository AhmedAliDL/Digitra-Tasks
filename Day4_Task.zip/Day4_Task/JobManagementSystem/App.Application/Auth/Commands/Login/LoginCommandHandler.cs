﻿using App.Application.Common.Exceptions;
using App.Application.Common.Interfaces;
using App.Application.DTOs.Auth;
using App.Domain.Entities;
using MediatR;
using System.IdentityModel.Tokens.Jwt;

namespace App.Application.Auth.Commands.Login
{
    public class LoginCommandHandler(
    IIdentityService identityService,
    IJwtTokenService jwtTokenService) : IRequestHandler<LoginCommand, TokenRefreshResultDto>
    {
        public async Task<TokenRefreshResultDto> Handle(LoginCommand request, CancellationToken cancellationToken)
        {
            ApplicationUser? user = await identityService.GetUserByEmailAsync(request.Email) ?? throw new ForbiddenException("Password or Email is invalid.");

            var checkPassword = await identityService.CheckCorrectnessOfPasswordAsync(user, request.Password);
            if (!checkPassword)
                throw new ForbiddenException("Password or Email is invalid.");
            var token = await jwtTokenService.CreateJWTTokenAsync(user);
            var response = new TokenRefreshResultDto
            {
                AccessToken = new JwtSecurityTokenHandler().WriteToken(token),
                AccessTokenExpiration = token.ValidTo,
                RefreshToken = "",
                RefreshTokenExpiration = token.ValidTo

            };
            if (user.RefreshTokens!.Any(rt => rt.IsActive))
            {
                var activeRefreshToken = user.RefreshTokens!.SingleOrDefault(t => t.IsActive);
                response.RefreshToken = activeRefreshToken!.Token;
                response.RefreshTokenExpiration = activeRefreshToken.ExpiresOn;
            }
            else
            {
                var refreshToken = jwtTokenService.CreateRefreshToken();
                response.RefreshToken = refreshToken.Token;
                response.RefreshTokenExpiration = refreshToken.ExpiresOn;
                user.RefreshTokens!.Add(refreshToken);
            }
            user.IsActive = true;
            user.LastLoginAt = DateTime.UtcNow;
            await identityService.UpdateUserAsync(user);

            return response;
        }
    }
}
