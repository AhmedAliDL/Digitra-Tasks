﻿using App.Application.DTOs.Auth;
using MediatR;

namespace App.Application.Auth.Commands.Login
{
    public record LoginCommand(string Email, string Password) : IRequest<TokenRefreshResultDto>;
}
