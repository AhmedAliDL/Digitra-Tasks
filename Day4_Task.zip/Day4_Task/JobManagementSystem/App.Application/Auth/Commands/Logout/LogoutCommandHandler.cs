﻿using App.Application.Common.Interfaces;
using App.Application.Responses;
using MediatR;

namespace App.Application.Auth.Commands.Logout
{
    public class LogoutCommandHandler(IJwtTokenService jwtTokenService) : IRequestHandler<LogoutCommand, ResponseResult<bool>>
    {
        public async Task<ResponseResult<bool>> Handle(LogoutCommand request, CancellationToken cancellationToken)
        {
            return await jwtTokenService.RevokeTokenAsync(request.RefreshToken);
        }
    }
}
