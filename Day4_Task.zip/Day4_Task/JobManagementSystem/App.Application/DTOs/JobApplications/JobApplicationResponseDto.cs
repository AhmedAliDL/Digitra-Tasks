using App.Domain.Enums;

namespace App.Application.DTOs.JobApplications;

public record JobApplicationResponseDto(
    Guid Id,
    Guid JobId,
    string JobTitle,
    Guid CandidateId,
    string CandidateName,
    string CVUrl,
    ApplicationStatus Status,
    DateTime AppliedAt,
    DateTime? StatusUpdatedAt,
    DateTime? CancelledAt
);
