namespace App.Application.DTOs.Auth;

public record TokenRefreshResultDto
{
    public string AccessToken { get; set; } = string.Empty;
    public DateTime AccessTokenExpiration { get; set; }
    public string RefreshToken = string.Empty;
    public DateTime RefreshTokenExpiration { get; set; }
}
