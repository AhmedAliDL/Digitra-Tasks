﻿using App.Application.Common.Interfaces;
using App.Application.DTOs.Jobs;
using MediatR;

namespace App.Application.Jobs.Queries.GetMyJobs
{
    public class GetMyJobsQueryHandler(
    ICurrentUserService currentUserService,
    IUnitOfWork unitOfWork) : IRequestHandler<GetMyJobsQuery, IReadOnlyList<JobResponseDto>>
    {
        public async Task<IReadOnlyList<JobResponseDto>> Handle(GetMyJobsQuery request, CancellationToken cancellationToken)
        {
            var recruiterId = currentUserService.UserId ?? throw new UnauthorizedAccessException("User is not authenticated.");
            var jobs = await unitOfWork.Jobs.FindAllAsync(j => j.RecruiterId == recruiterId, includes: [j => j.Applications], cancellationToken);
            return [.. jobs.Select(j => new JobResponseDto(
                Id: j.Id,
                Title: j.Title,
                Description: j.Description,
                IsActive: j.IsActive,
                RecruiterId: j.RecruiterId,
                ClosedAt: j.ClosedAt,
                ApplicationCount: j.Applications.Count))];
        }
    }
}
