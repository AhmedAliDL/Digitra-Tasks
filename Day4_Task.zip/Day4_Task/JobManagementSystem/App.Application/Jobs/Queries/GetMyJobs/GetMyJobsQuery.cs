﻿using App.Application.DTOs.Jobs;
using MediatR;

namespace App.Application.Jobs.Queries.GetMyJobs
{
    public record GetMyJobsQuery : IRequest<IReadOnlyList<JobResponseDto>>;
}
