﻿using App.Application.Common.Exceptions;
using App.Application.Common.Interfaces;
using App.Application.DTOs.Jobs;
using MediatR;

namespace App.Application.Jobs.Queries.GetJobById
{
    public class GetJobByIdQueryHandler(IUnitOfWork unitOfWork) : IRequestHandler<GetJobByIdQuery, JobResponseDto>
    {
        public async Task<JobResponseDto> Handle(GetJobByIdQuery request, CancellationToken cancellationToken)
        {
            var job = await unitOfWork.Jobs.GetByIdAsync(request.JobId, cancellationToken)
             ?? throw new NotFoundException($"Job '{request.JobId}' was not found.");

            return new JobResponseDto(
                Id: job.Id,
                Title: job.Title,
                Description: job.Description,
                IsActive: job.IsActive,
                RecruiterId: job.RecruiterId,
                ClosedAt: job.ClosedAt,
                ApplicationCount: job.Applications.Count);
        }
    }
}
