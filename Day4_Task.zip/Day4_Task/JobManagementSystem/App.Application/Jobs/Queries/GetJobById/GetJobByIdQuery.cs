﻿using App.Application.DTOs.Jobs;
using MediatR;

namespace App.Application.Jobs.Queries.GetJobById
{
    public record GetJobByIdQuery(Guid JobId) : IRequest<JobResponseDto>;
}
