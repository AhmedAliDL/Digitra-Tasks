﻿using App.Application.DTOs.Jobs;
using MediatR;

namespace App.Application.Jobs.Queries.GetActiveJob
{
    public record GetActiveJobQuery : IRequest<IReadOnlyList<JobResponseDto>>;
}
