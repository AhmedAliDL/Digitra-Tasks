﻿using App.Application.Common.Interfaces;
using App.Application.DTOs.Jobs;
using MediatR;

namespace App.Application.Jobs.Queries.GetActiveJob
{
    public class GetActiveJobQueryHandler(IUnitOfWork unitOfWork) : IRequestHandler<GetActiveJobQuery, IReadOnlyList<JobResponseDto>>
    {
        public async Task<IReadOnlyList<JobResponseDto>> Handle(GetActiveJobQuery request, CancellationToken cancellationToken)
        {
            var jobs = await unitOfWork.Jobs.FindAllAsync(j => j.IsActive, includes: [j => j.Applications], cancellationToken);
            return [.. jobs.Select( j => new JobResponseDto(
                Id: j.Id,
                Title: j.Title,
                Description: j.Description,
                IsActive: j.IsActive,
                RecruiterId: j.RecruiterId,
                ClosedAt: j.ClosedAt,
                ApplicationCount: j.Applications.Count))];
        }
    }
}
