﻿using App.Application.Common.Exceptions;
using App.Application.Common.Interfaces;
using MediatR;

namespace App.Application.Jobs.Commands.CloseJob
{
    public class CloseJobCommandHandler(
    ICurrentUserService currentUserService,
    IUnitOfWork unitOfWork) : IRequestHandler<CloseJobCommand, int>
    {
        public async Task<int> Handle(CloseJobCommand request, CancellationToken cancellationToken)
        {
            var recruiterId = currentUserService.UserId ?? throw new UnauthorizedAccessException("User is not authenticated.");

            var job = await unitOfWork.Jobs.GetByIdAsync(request.JobId, cancellationToken)
                      ?? throw new NotFoundException($"Job '{request.JobId}' was not found.");
            if (job.RecruiterId != recruiterId)
                throw new UnauthorizedAccessException("You are not authorized to close this job.");

            if (!job.IsActive)
                throw new ValidationException("This job is already closed.");

            job.IsActive = false;
            job.ClosedAt = DateTime.UtcNow;
            unitOfWork.Jobs.Update(job);
            return await unitOfWork.CompleteAsync(cancellationToken);
        }
    }
}
