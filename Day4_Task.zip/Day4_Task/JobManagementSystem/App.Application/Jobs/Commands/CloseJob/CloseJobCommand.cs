﻿using MediatR;

namespace App.Application.Jobs.Commands.CloseJob
{
    public record CloseJobCommand(Guid JobId) : IRequest<int>;
}
