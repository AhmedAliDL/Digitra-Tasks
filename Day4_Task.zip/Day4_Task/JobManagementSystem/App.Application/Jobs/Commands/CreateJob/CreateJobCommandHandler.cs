﻿using App.Application.Common.Interfaces;
using App.Domain.Entities;
using MediatR;

namespace App.Application.Jobs.Commands.CreateJob
{
    public class CreateJobCommandHandler(
    ICurrentUserService currentUserService,
    IUnitOfWork unitOfWork) : IRequestHandler<CreateJobCommand, Guid>
    {
        public async Task<Guid> Handle(CreateJobCommand request, CancellationToken cancellationToken = default)
        {
            var recruiterId = currentUserService.UserId ?? throw new UnauthorizedAccessException("User is not authenticated.");

            var job = new Job
            {
                Id = Guid.NewGuid(),
                Title = request.Title,
                Description = request.Description,
                IsActive = true,
                RecruiterId = recruiterId,
            };

            await unitOfWork.Jobs.AddAsync(job, cancellationToken);
            await unitOfWork.CompleteAsync(cancellationToken);

            return job.Id;
        }
    }
}
