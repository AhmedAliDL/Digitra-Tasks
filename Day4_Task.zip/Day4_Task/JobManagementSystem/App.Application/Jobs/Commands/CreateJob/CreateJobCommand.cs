﻿using MediatR;

namespace App.Application.Jobs.Commands.CreateJob
{
    public record CreateJobCommand(string Title,
    string Description) : IRequest<Guid>;
}
