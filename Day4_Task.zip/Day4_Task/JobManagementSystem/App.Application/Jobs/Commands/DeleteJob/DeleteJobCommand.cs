﻿using MediatR;

namespace App.Application.Jobs.Commands.DeleteJob
{
    public record DeleteJobCommand(Guid JobId) : IRequest<int>;
}
