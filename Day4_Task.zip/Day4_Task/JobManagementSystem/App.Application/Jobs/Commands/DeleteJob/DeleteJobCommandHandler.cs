﻿using App.Application.Common.Exceptions;
using App.Application.Common.Interfaces;
using MediatR;

namespace App.Application.Jobs.Commands.DeleteJob
{
    public class DeleteJobCommandHandler(
    ICurrentUserService currentUserService,
    IUnitOfWork unitOfWork) : IRequestHandler<DeleteJobCommand, int>
    {
        public async Task<int> Handle(DeleteJobCommand request, CancellationToken cancellationToken)
        {
            var recruiterId = currentUserService.UserId ?? throw new UnauthorizedAccessException("User is not authenticated.");

            var job = await unitOfWork.Jobs.GetByIdAsync(request.JobId, cancellationToken)
                      ?? throw new NotFoundException($"Job '{request.JobId}' was not found.");

            if (job.RecruiterId != recruiterId)
                throw new UnauthorizedAccessException("You are not authorized to delete this job.");

            unitOfWork.Jobs.Delete(job);
          return await unitOfWork.CompleteAsync(cancellationToken);
        }
    }
}
