﻿using App.Application.Jobs.Commands.CloseJob;
using App.Application.Jobs.Commands.CreateJob;
using App.Application.Jobs.Commands.DeleteJob;
using App.Application.Jobs.Queries.GetActiveJob;
using App.Application.Jobs.Queries.GetJobById;
using App.Application.Jobs.Queries.GetMyJobs;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace App.Api.Controllers
{
    /// <summary>
    /// Provides endpoints for managing jobs.
    /// </summary>
    [Route("api")]
    [Authorize]
    [ApiController]
    public class JobController(IMediator mediator) : ControllerBase
    {
        /// <summary>
        /// Retrieves a job by its identifier.
        /// </summary>
        /// <param name="id">The unique identifier of the job.</param>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>The requested job, or a not found response if the job does not exist.</returns>
        [HttpGet("jobs/{id:guid}")]
        public async Task<IActionResult> GetJobById(
            Guid id,
            CancellationToken cancellationToken)
        {
            var result = await mediator.Send(
                new GetJobByIdQuery(id),
                cancellationToken);

            if (result is null)
                return NotFound();

            return Ok(result);
        }

        /// <summary>
        /// Retrieves all jobs created by the authenticated recruiter.
        /// </summary>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>A collection of jobs created by the authenticated recruiter.</returns>
        [Authorize(Roles = "recruiter")]
        [HttpGet("jobs/my")]
        public async Task<IActionResult> GetMyJobs(
            CancellationToken cancellationToken)
        {
            var result = await mediator.Send(
                new GetMyJobsQuery(),
                cancellationToken);

            return Ok(result);
        }

        /// <summary>
        /// Retrieves all currently active jobs.
        /// </summary>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>A collection of active jobs.</returns>
        [HttpGet("jobs/active")]
        public async Task<IActionResult> GetActiveJobs(
            CancellationToken cancellationToken)
        {
            var result = await mediator.Send(
                new GetActiveJobQuery(),
                cancellationToken);

            return Ok(result);
        }

        /// <summary>
        /// Creates a new job.
        /// </summary>
        /// <param name="request">The job information to create.</param>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>The unique identifier of the newly created job.</returns>
        [Authorize(Roles = "recruiter")]
        [HttpPost("jobs")]
        public async Task<IActionResult> CreateJob(
            [FromBody] CreateJobCommand request,
            CancellationToken cancellationToken)
        {
            var result = await mediator.Send(request, cancellationToken);

            if (result == Guid.Empty)
                return BadRequest(result);

            return Ok(result);
        }

        /// <summary>
        /// Closes an existing job.
        /// </summary>
        /// <param name="id">The unique identifier of the job to close.</param>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>No content when the job is closed successfully.</returns>
        [Authorize(Roles = "recruiter")]
        [HttpPut("jobs/{id:guid}/close")]
        public async Task<IActionResult> CloseJob(
            Guid id,
            CancellationToken cancellationToken)
        {
            await mediator.Send(
                new CloseJobCommand(id),
                cancellationToken);

            return NoContent();
        }

        /// <summary>
        /// Deletes an existing job.
        /// </summary>
        /// <param name="id">The unique identifier of the job to delete.</param>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>No content when the job is deleted successfully.</returns>
        [Authorize(Roles = "recruiter")]
        [HttpDelete("jobs/{id:guid}")]
        public async Task<IActionResult> DeleteJob(
            Guid id,
            CancellationToken cancellationToken)
        {
            await mediator.Send(
                new DeleteJobCommand(id),
                cancellationToken);

            return NoContent();
        }
    }
}