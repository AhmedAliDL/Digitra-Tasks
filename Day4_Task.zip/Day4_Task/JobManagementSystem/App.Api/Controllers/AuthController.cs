﻿using App.Application.Auth.Commands.Login;
using App.Application.Auth.Commands.Logout;
using App.Application.Auth.Commands.RefreshToken;
using App.Application.Auth.Commands.Register;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace App.Api.Controllers
{
    /// <summary>
    /// Provides endpoints for user authentication and account session management.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController(IMediator mediator) : ControllerBase
    {
        /// <summary>
        /// Authenticates a user and returns an access token with a refresh token.
        /// </summary>
        /// <param name="request">The login credentials.</param>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>The authentication result containing the access token and refresh token.</returns>
        [HttpPost("login")]
        public async Task<IActionResult> Login(
            [FromBody] LoginCommand request,
            CancellationToken cancellationToken = default)
        {
            var result = await mediator.Send(request, cancellationToken);

            if (result is null)
                return BadRequest(result);

            SetTokenCookie(result.RefreshToken);

            return Ok(result);
        }

        /// <summary>
        /// Registers a new user account.
        /// </summary>
        /// <param name="request">The user registration information.</param>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>The unique identifier of the newly registered user.</returns>
        [HttpPost("register")]
        public async Task<IActionResult> Register(
            [FromBody] RegisterCommand request,
            CancellationToken cancellationToken = default)
        {
            var result = await mediator.Send(request, cancellationToken);

            if (result == Guid.Empty)
                return BadRequest(result);

            return Ok(result);
        }

        /// <summary>
        /// Generates a new access token using the authenticated user's refresh token.
        /// </summary>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>A new authentication result containing the refreshed access token.</returns>
        [Authorize]
        [HttpPost("refresh-token")]
        public async Task<IActionResult> RefreshToken(
            CancellationToken cancellationToken = default)
        {
            var refreshToken = Request.Cookies["refresh_Token"];

            if (string.IsNullOrEmpty(refreshToken))
                return BadRequest("Refresh token is missing.");

            var result = await mediator.Send(
                new RefreshTokenCommand(refreshToken),
                cancellationToken);

            if (result is null)
                return BadRequest(result);

            return Ok(result);
        }

        /// <summary>
        /// Stores the refresh token in an HTTP-only cookie.
        /// </summary>
        /// <param name="token">The refresh token to store in the cookie.</param>
        private void SetTokenCookie(string token)
        {
            var cookieOptions = new CookieOptions
            {
                HttpOnly = true,
                Expires = DateTime.UtcNow.AddDays(7)
            };

            Response.Cookies.Append("refresh_Token", token, cookieOptions);
        }

        /// <summary>
        /// Logs out the authenticated user and revokes the current refresh token.
        /// </summary>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>No content when logout succeeds; otherwise, a bad request response.</returns>
        [Authorize]
        [HttpPost("logout")]
        public async Task<IActionResult> Logout(
            CancellationToken cancellationToken = default)
        {
            var refreshToken = Request.Cookies["refresh_Token"];

            if (string.IsNullOrEmpty(refreshToken))
                return BadRequest("Refresh token is missing.");

            var res = await mediator.Send(
                new LogoutCommand(refreshToken),
                cancellationToken);

            if (res.IsSuccess == false)
                return BadRequest(res);

            Response.Cookies.Delete("refresh_Token");

            return NoContent();
        }
    }
}