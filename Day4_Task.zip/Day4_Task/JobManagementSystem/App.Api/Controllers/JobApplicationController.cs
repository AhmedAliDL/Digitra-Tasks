﻿using App.Application.JobApplications.Commands.ApplyForJob;
using App.Application.JobApplications.Commands.CancelApplication;
using App.Application.JobApplications.Commands.UpdateStatus;
using App.Application.JobApplications.Queries.GetApplicationById;
using App.Application.JobApplications.Queries.GetApplicationsByJobId;
using App.Application.JobApplications.Queries.GetMyApplications;
using App.Domain.Enums;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace App.Api.Controllers
{
    /// <summary>
    /// Provides endpoints for managing job applications.
    /// </summary>
    [Route("api/")]
    [Authorize]
    [ApiController]
    public class JobApplicationController(IMediator mediator) : ControllerBase
    {
        /// <summary>
        /// Retrieves all applications submitted by the authenticated candidate.
        /// </summary>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>A collection of the candidate's job applications.</returns>
        [Authorize(Roles = "candidate")]
        [HttpGet("applications/my")]
        public async Task<IActionResult> GetMyApplications(
            CancellationToken cancellationToken)
        {
            var result = await mediator.Send(
                new GetMyApplicationsQuery(),
                cancellationToken);

            return Ok(result);
        }

        /// <summary>
        /// Retrieves a job application by its identifier.
        /// </summary>
        /// <param name="id">The unique identifier of the job application.</param>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>The requested job application, or a not found response if it does not exist.</returns>
        [HttpGet("applications/{id:guid}")]
        public async Task<IActionResult> GetApplicationById(
            Guid id,
            CancellationToken cancellationToken)
        {
            var result = await mediator.Send(
                new GetApplicationByIdQuery(id),
                cancellationToken);

            if (result is null)
                return NotFound();

            return Ok(result);
        }

        /// <summary>
        /// Retrieves all applications submitted for a specific job.
        /// </summary>
        /// <param name="jobId">The unique identifier of the job.</param>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>A collection of applications submitted for the specified job.</returns>
        [Authorize(Roles = "recruiter")]
        [HttpGet("jobs/{jobId:guid}/applications")]
        public async Task<IActionResult> GetApplicationsByJobId(
            Guid jobId,
            CancellationToken cancellationToken)
        {
            var result = await mediator.Send(
                new GetApplicationsByJobIdQuery(jobId),
                cancellationToken);

            return Ok(result);
        }

        /// <summary>
        /// Submits a job application for the specified job.
        /// </summary>
        /// <param name="id">The unique identifier of the job.</param>
        /// <param name="cvUrl">The optional URL of the candidate's CV.</param>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>A success response when the application is submitted successfully.</returns>
        [Authorize(Roles = "candidate")]
        [HttpPost("jobs/{id:guid}/apply")]
        public async Task<IActionResult> ApplyToJob(
            Guid id,
            [FromQuery] string? cvUrl,
            CancellationToken cancellationToken)
        {
            var result = await mediator.Send(
                new ApplyForJobCommand(id, cvUrl),
                cancellationToken);

            if (result == Guid.Empty)
                return BadRequest("Failed to apply to the job.");

            return Ok("Successfully applied to the job.");
        }

        /// <summary>
        /// Updates the status of a job application.
        /// </summary>
        /// <param name="id">The unique identifier of the job application.</param>
        /// <param name="newStatus">The new status to assign to the application.</param>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>A success response when the application status is updated successfully.</returns>
        [Authorize(Roles = "recruiter")]
        [HttpPut("applications/{id:guid}/status")]
        public async Task<IActionResult> UpdateApplicationStatus(
            Guid id,
            [FromBody] ApplicationStatus newStatus,
            CancellationToken cancellationToken)
        {
            if (!Enum.TryParse(
                    newStatus.ToString(),
                    true,
                    out App.Domain.Enums.ApplicationStatus status))
            {
                return BadRequest("Invalid status value.");
            }

            var result = await mediator.Send(
                new UpdateStatusCommand(id, status),
                cancellationToken);

            if (result == 0)
                return NotFound("Application not found or status not updated.");

            return Ok("Application status updated successfully.");
        }

        /// <summary>
        /// Cancels a job application submitted by the authenticated candidate.
        /// </summary>
        /// <param name="id">The unique identifier of the job application.</param>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>No content when the application is cancelled successfully.</returns>
        [Authorize(Roles = "candidate")]
        [HttpDelete("applications/{id:guid}/cancel")]
        public async Task<IActionResult> CancelApplication(
            Guid id,
            CancellationToken cancellationToken)
        {
            await mediator.Send(
                new CancelApplicationCommand(id),
                cancellationToken);

            return NoContent();
        }
    }
}