using App.Domain.Enums;
using App.Domain.Interfaces;

namespace App.Domain.Entities;

public class JobApplication : ISoftDeletable
{
    public Guid Id { get; set; }

    public Guid JobId { get; set; }
    public Job? Job { get; set; }

    public Guid CandidateId { get; set; }
    public ApplicationUser? Candidate { get; set; }

    public DateTime AppliedAt { get; set; }
    public DateTime? CancelledAt { get; set; }
    public DateTime? StatusUpdatedAt { get; set; }

    public ApplicationStatus Status { get; set; }

    public string CVUrl { get; set; } = string.Empty;

    public bool IsDeleted { get; set; }
    public DateTime? DeletedAt { get; set; }
}
