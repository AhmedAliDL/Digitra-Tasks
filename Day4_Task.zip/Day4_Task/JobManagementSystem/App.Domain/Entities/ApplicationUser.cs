using Microsoft.AspNetCore.Identity;

namespace App.Domain.Entities;
public class ApplicationUser : IdentityUser<Guid>
{
    public string CVUrl { get; set; } = string.Empty;
    public string FName { get; set; } = string.Empty;
    public string LName { get; set; } = string.Empty;
    public string? Address { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime? LastLoginAt { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public ICollection<RefreshToken>? RefreshTokens { get; set; } = null!;
}
