using App.Domain.Interfaces;

namespace App.Domain.Entities;

public class Job : ISoftDeletable
{
    public Guid Id { get; set; }
    public string Title { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public bool IsActive { get; set; } = true;

    public Guid RecruiterId { get; set; }
    public DateTime? ClosedAt { get; set; }

    public ICollection<JobApplication> Applications { get; set; } = [];

    public bool IsDeleted { get; set; }
    public DateTime? DeletedAt { get; set; }


}
