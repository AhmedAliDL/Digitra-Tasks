namespace App.Domain.Enums;

public enum ApplicationStatus
{
    Applied,
    UnderReview,
    Interview,
    Accepted,
    Rejected,
    Cancelled
}
