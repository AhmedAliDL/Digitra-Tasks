﻿using App.Application.Common.Interfaces;
using App.Domain.Entities;
using App.Infrastructure.Persistance;
using App.Infrastructure.Repositories;

namespace App.Infrastructure.UnitOfWork
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly AppDbContext _context;
        public UnitOfWork(AppDbContext context)
        {
            _context = context;
            Jobs = new BaseRepository<Job>(_context);
            Candidates = new BaseRepository<ApplicationUser>(_context);
            JobApplications = new BaseRepository<JobApplication>(_context);

        }
        public IBaseRepository<Job> Jobs { get; private set; }

        public IBaseRepository<ApplicationUser> Candidates { get; private set; }

        public IBaseRepository<JobApplication> JobApplications { get; private set; }

        public async Task<int> CompleteAsync(CancellationToken cancellationToken = default)
        {
            return await _context.SaveChangesAsync(cancellationToken);
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            _context.Dispose();
        }

    }
}
