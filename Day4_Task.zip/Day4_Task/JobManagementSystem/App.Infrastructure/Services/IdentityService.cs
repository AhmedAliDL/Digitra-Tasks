﻿using App.Application.Common.Interfaces;
using App.Domain.Entities;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace App.Infrastructure.Services
{
    public class IdentityService(UserManager<ApplicationUser> userManager) : IIdentityService
    {
        public async Task<IdentityResult> CreateUserAsync(ApplicationUser user, string password)
        {
            return await userManager.CreateAsync(user, password);
        }
        public async Task<List<ApplicationUser>> GetUsersByIdsAsync(List<Guid> ids)
        {
            return await userManager.Users.Where(u => ids.Contains(u.Id)).ToListAsync();
        }
        public async Task<ApplicationUser?> GetUserByEmailAsync(string email)
        {
            return await userManager.FindByEmailAsync(email);
        }
        public async Task<ApplicationUser?> GetUserByIdAsync(Guid userId)
        {
            return await userManager.Users.FirstOrDefaultAsync(u => u.Id == userId);
        }
        public async Task<bool> CheckCorrectnessOfPasswordAsync(ApplicationUser user, string password)
        {
            return await userManager.CheckPasswordAsync(user, password);
        }
        public async Task<IdentityResult> UpdateUserAsync(ApplicationUser user)
        {
            return await userManager.UpdateAsync(user);
        }
        public bool CheckEmailUniqueness(string email)
        {
            return userManager.Users.Any(u => u.Email == email);
        }

    }
}
