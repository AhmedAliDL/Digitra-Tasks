﻿using App.Application.Common.Interfaces;
using App.Domain.Entities;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace App.Infrastructure.Services
{
    public class RoleService(RoleManager<ApplicationRole> roleManager, UserManager<ApplicationUser> userManager) : IRoleService
    {

        public async Task<List<ApplicationRole>> GetAllRolesAsync()
        {
            var roles = await roleManager.Roles.ToListAsync();

            return roles;

        }
        public async Task<IList<string>> GetAllRolesOfUser(ApplicationUser user)
        {
            return await userManager.GetRolesAsync(user);
        }
        public async Task<bool> IsRoleExistsAsync(string roleName)
        {
            return await roleManager.RoleExistsAsync(roleName);
        }
        public async Task<IdentityResult> CreateRoleAsync(string roleName, string roleDescription)
        {

            var role = new ApplicationRole
            {
                Name = roleName,
                Description = roleDescription
            };
            var result = await roleManager.CreateAsync(role);
            return result;
        }
        public async Task<IdentityResult> AssignRoleToUserAsync(ApplicationUser user, string roleName)
        {

            var result = await userManager.AddToRoleAsync(user, roleName);
            return result;
        }
        public async Task<bool> DeleteAssignRoleAsync(ApplicationUser user, string roleName)
        {
            var result = await userManager.RemoveFromRoleAsync(user, roleName);
            return result.Succeeded;
        }
        public async Task<ApplicationRole?> GetRoleAsync(string roleName)
        {
            return await roleManager.FindByNameAsync(roleName);
        }
        public async Task<bool> DeleteRoleAsync(ApplicationRole role)
        {

            var result = await roleManager.DeleteAsync(role);
            return result.Succeeded;
        }

    }
}
