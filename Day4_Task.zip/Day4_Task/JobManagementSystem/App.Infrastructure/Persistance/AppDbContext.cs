﻿using App.Domain.Entities;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace App.Infrastructure.Persistance
{
    public class AppDbContext : IdentityDbContext<ApplicationUser, ApplicationRole, Guid>
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {

        }
        public DbSet<Job> Jobs => Set<Job>();
        public DbSet<ApplicationUser> Candidates => Set<ApplicationUser>();
        public DbSet<JobApplication> JobApplications => Set<JobApplication>();

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);

        }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<Job>().HasQueryFilter(j => !j.IsDeleted);
            builder.Entity<JobApplication>().HasQueryFilter(ja => !ja.IsDeleted);

            builder.Entity<ApplicationUser>().HasIndex(u => u.Email).IsUnique();
            builder.Entity<ApplicationUser>()
            .OwnsMany(u => u.RefreshTokens, tokenBuilder =>
            {
                tokenBuilder.Property(t => t.Token)
                    .HasMaxLength(256)
                    .IsRequired();

                tokenBuilder.HasIndex(t => t.Token);
            });
        }
    }
}
