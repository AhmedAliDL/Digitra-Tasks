﻿using App.Application.Common.Interfaces;
using App.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace App.Infrastructure.Persistance.Seed
{
    public class DatabaseSeeder
    {

        public static async Task SeedAsync(IServiceProvider serviceProvider)
        {
            using var scope = serviceProvider.CreateScope();
            var context = scope.ServiceProvider.GetRequiredService<AppDbContext>();
            var roleService = scope.ServiceProvider.GetRequiredService<IRoleService>();
            var userService = scope.ServiceProvider.GetRequiredService<IIdentityService>();


            await context.Database.MigrateAsync();

            await SeedRolesAsync(roleService);

            await SeedRecruiterAsync(userService, roleService);

        }
        private static async Task SeedRolesAsync(IRoleService roleService)
        {
            string roleName = "recruiter";

            if (await roleService.IsRoleExistsAsync(roleName))
                return;

            var result = await roleService.CreateRoleAsync(roleName, "initial recruiter for system.");
            if (!result.Succeeded)
            {
                var errors = string.Join(
                    ", ",
                    result.Errors.Select(e => e.Description));

                throw new Exception(
                    $"Failed to create role '{roleName}': {errors}");
            }

        }
        private static async Task SeedRecruiterAsync(IIdentityService userService, IRoleService roleService)
        {
            string recruiterEmail = "recruiter@example.com";
            var existingRecruiter = await userService.GetUserByEmailAsync(recruiterEmail);

            if (existingRecruiter is not null)
                return;
            var recruiter = new ApplicationUser
            {
                FName = "Ahmed",
                LName = "Ali",
                UserName = recruiterEmail,
                Email = recruiterEmail,
                EmailConfirmed = true,
            };
            var res = await userService.CreateUserAsync(recruiter, "AhMq3das123!");
            if (!res.Succeeded)
            {
                var errors = string.Join(
                    ", ",
                    res.Errors.Select(e => e.Description));

                throw new Exception(
                    $"Failed to create admin user: {errors}");
            }

            await roleService.AssignRoleToUserAsync(recruiter, "recruiter");

        }
    }
}
